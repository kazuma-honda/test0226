describe('Node.js Kafka Simple template', () => {
    describe('app', () => {
        it('can be required', () => {
          const App = require('../');
        });
    });
});
